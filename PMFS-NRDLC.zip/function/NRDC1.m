function [W, D, N, obj] = NRDC1(X, Y, param)
% (W'*X+b1'-D, f)
% + (Y-(D+N), f)
% + lambda1*trace(D*M*D')
% + lambda2*trace(W*L*W')
% + lambda3*(N, 1)
% + lambda4*||W||_2,1

%% parameters setting
[num_dim, num_sample] = size(X);
num_class = size(Y, 1);
lambda1 = param.lambda1;
lambda2 = param.lambda2;
lambda3 = param.lambda3;
lambda4 = param.lambda4;
k = param.k;
maxIter = param.maxIter;
minLossMargin = param.minLossMargin;
lr = 1e-4;
disp('Optimization Start---');

%% Initialization for iteration
Sf = build_data_manifold(X', Y', k);
M = (eye(num_sample)-Sf)'*(eye(num_sample)-Sf);
D = Y;
N = zeros(num_class, num_sample);
L = LabelCorrelation(D);
X = [X; ones(1,num_sample)];
W = (X*X'+lambda4*eye(num_dim+1))\(X*Y');
XXT = X*X';
T = 2*((lambda1+1)*eye(num_sample) + lambda1*(Sf'*Sf +...
    (Sf'*ones(num_sample,num_sample)*Sf).*eye(num_sample)-2*Sf));
T1 = repmat({T},1,num_class);
H = spblkdiag(T1{:});
H = (H+H')/2;
lb = sparse(num_sample*num_class,1);
ub = ones(num_sample*num_class,1);
options = optimoptions('quadprog',...
'Display', 'off','Algorithm','interior-point-convex' );

oldobj = Inf;
iter = 1;
obj = [];
%% Optimization in iter
while iter <= maxIter
     % W subproblem
      U = Proximate(W);
      Grad_W = 2*XXT*W - X*D' + 2*lambda2*W*L + 2*lambda4*U*W;
      W = W - Grad_W*lr;
      if mod(10, iter) == 0
        lr = lr*0.1;
      end
      lr = max(lr, 1e-6);
     
     % D subproblem
      c = reshape(-2*(W'*X+Y-N),num_sample*num_class,1);
      Outputs= quadprog(H, c, [],[], [], [], lb, ub,[], options);
      D = reshape(Outputs,num_class,num_sample);
      
     % N subproblem
      Y1 = Y - D;
      N = max(Y1-lambda3/2,0)+min(Y1+lambda3/2,0);
      N(Y==0) = 0;
      N(N<0) = 0;
      N(N>1) = 1;
      
      % upadte label correlation
       L = LabelCorrelation(D);
       
       % Calculate objective function
       currobj = norm(W'*X-D,'fro')^2 + 0.5*norm(D+N-Y,'fro')^2 + lambda1*trace(D*M*D')...
                 + lambda2*trace(W*L*W') + lambda3*sum(sum(abs(N))) + lambda4*sum(sqrt(sum(W.*W,2)));
       obj(iter) = currobj;
       if (abs(oldobj - currobj) < minLossMargin*abs(currobj)) && (iter > 5)
           break;
       end
       if currobj > oldobj && iter > 5
           break;
       end
       oldobj = currobj;
       iter = iter + 1; 
end
end

%% Calculate U
function U = Proximate(W)
num = size(W, 1);
U = zeros(num, num);
for i = 1:num
    temp = norm(W(i, :), 2);
    if temp ~= 0
        U(i, i) = 1/temp;
    else
        U(i, i) = 0;
    end
end
end



