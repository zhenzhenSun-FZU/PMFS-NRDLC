function predict_target = Predict(Outputs,par_label)
    tau = 1./sum(par_label,1);
    [num_class,num_sample] = size(Outputs);
    outputValue=Outputs;
    for i=1:num_sample
        outputValue(:,i)=(outputValue(:,i)-min(min(outputValue(:,i))))/(max(max(outputValue(:,i)))-min(min(outputValue(:,i))));
    end
    predict_target = zeros(num_class,num_sample);
     for i=1:num_sample
        predict_target(:,i)= outputValue(:,i)>=tau(i);
     end
end
