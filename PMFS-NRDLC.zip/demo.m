clc; clear; 
addpath(genpath('.\'))
DataName={'music_emotion'};
select_ratio = 0.05:0.05:0.5;
dst_folder = "results";
n_fold = 5;
Num = 10;Smooth = 1; %parameters for MLKNN
for dataN=1:length(DataName)
    dataset=DataName{dataN};
    path=strcat('./data/',dataset);
    load(path);
    target = target';
    partial_labels = partial_labels';
    %Delete samples that have no labels
    indx = find((sum(target,2))==0);
    data(indx,:) = [];
    target(indx,:) = [];
    partial_labels(indx,:) = [];
    [n_sample, n_feature] = size(data);
    n_test = round(n_sample / n_fold); 
    result_path=strcat(dst_folder,'/',dataset,'/');
    if ~exist(result_path, 'dir')
        mkdir(result_path);
    end
    Total_Result = zeros(15,10); Mean_Result = zeros(15,10);
    for cv = 1:n_fold 
        fprintf('Data processing, Cross validation: %d\n', cv);
        % split data
        start_idx = (cv-1)*n_test + 1;
        if cv == n_fold
            test_idx = start_idx : n_sample;
        else
            test_idx = start_idx:start_idx + n_test - 1;
        end
        II = 1:n_sample;
        train_idx = setdiff(II, test_idx);
        train_data = data(train_idx, :);
        train_target = target(train_idx,:);
        train_p_target = partial_labels(train_idx,:);
        test_data = data(test_idx, :);
        test_target = target(test_idx,:);
        [train_data, settings]=mapminmax(train_data');
        test_data=mapminmax('apply',test_data',settings);
        train_data=train_data';
        test_data=test_data';
        train_data(isnan(train_data))=0;
        test_data(isnan(test_data))=0;

        param.k = 20; param.maxIter = 100; param.minLossMargin = 1e-5; 
        param.lambda1 = 1000; param.lambda2 = 100; param.lambda3 = 1e-6; param.lambda4 = 1000;
        tic;
        [W, D, N, obj] = NRDC(train_data', train_p_target', param);
        time = toc;
        [dumb,idx] = sort(sum(W(1:n_feature,:).*W(1:n_feature,:),2),'descend');
        predict_train_target = Predict(train_p_target'-N,train_p_target');
        predict_train_target(predict_train_target==0)=-1;
        test_target(test_target==0) = -1;
        
        MetricResult = zeros(15, length(select_ratio));   
        for d = 1:length(select_ratio)
            select_num = ceil(n_feature*select_ratio(d));
          f = idx(1:select_num);
          [Prior,PriorN,Cond,CondN]=MLKNN_train(train_data(:,f), predict_train_target,Num,Smooth);
          [HammingLoss,RankingLoss,Coverage,Average_Precision,macrof1,microf1,Outputs,Pre_Labels]=...
                           MLKNN_test(train_data(:,f), predict_train_target, test_data(:,f),test_target',Num,Prior,PriorN,Cond,CondN); 
          fprintf('-- Evaluation\n');
          tmpResult = EvaluationAll(Pre_Labels,Outputs,test_target');
          MetricResult(:,d) = tmpResult; 
        end
        Result_cross{cv,1} = MetricResult;
        Total_Result = Total_Result + MetricResult;
    end
    Mean_Result = Total_Result./5;
    savepath=strcat(result_path,'result.mat');
    save(savepath,'Result_cross','Mean_Result','time');           
end

